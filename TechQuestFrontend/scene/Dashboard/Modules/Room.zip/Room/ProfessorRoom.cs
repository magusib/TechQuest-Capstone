using Godot;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

public partial class ProfessorRoom : Control
{
	private Button backButton;
	private Button createRoomButton;

	private Window createRoomWindow;
	private LineEdit subjectNameInput;

	private Label roomCodeLabel;
	private Label codeLabel;

	private Button generateCodeButton;
	private Button saveButton;
	private Button cancelButton;

	// ScrollContainer -> VBoxContainer -> RoomListPanel -> RoomListContainer
	private ScrollContainer roomScrollContainer;
	private VBoxContainer roomListContainer;
	private Panel roomListPanel;

	private ConfirmationDialog deleteRoomConfirmation;
	private ConfirmationDialog closeRoomConfirmation;

	// Original template children inside RoomListContainer.
	private Godot.Collections.Array<Node> roomTemplate;

	private string generatedRoomCode = "";

	private int pendingDeleteRoomId = 0;
	private int pendingCloseRoomId = 0;

	public override void _Ready()
	{
		// ---------------------------------------------------------
		// BASIC UI
		// ---------------------------------------------------------

		backButton = GetNode<Button>("BackButton");
		createRoomButton = GetNode<Button>("CreateRoomButton");

		createRoomWindow = GetNode<Window>("CreateRoomWindow");

		subjectNameInput = GetNode<LineEdit>(
			"CreateRoomWindow/CreateRoomPanel/RoomCodeContainer/SubjectNameInput"
		);

		roomCodeLabel = GetNode<Label>(
			"CreateRoomWindow/CreateRoomPanel/RoomCodeContainer/RoomCodeLabel"
		);

		codeLabel = GetNode<Label>(
			"CreateRoomWindow/CreateRoomPanel/RoomCodeContainer/CodeLabel"
		);

		generateCodeButton = GetNode<Button>(
			"CreateRoomWindow/CreateRoomPanel/RoomCodeContainer/GenerateCodeButton"
		);

		saveButton = GetNode<Button>(
			"CreateRoomWindow/CreateRoomPanel/RoomCodeContainer/RoomButtonContainer/SaveButton"
		);

		cancelButton = GetNode<Button>(
			"CreateRoomWindow/CreateRoomPanel/RoomCodeContainer/RoomButtonContainer/CancelButton"
		);

		// ---------------------------------------------------------
		// SCROLL CONTAINER
		// ---------------------------------------------------------

		roomScrollContainer = GetNode<ScrollContainer>(
			"RoomManagementPanel/ScrollContainer"
		);

		roomListContainer = GetNode<VBoxContainer>(
			"RoomManagementPanel/ScrollContainer/VBoxContainer/RoomListPanel/RoomListContainer"
		);

		roomListPanel = GetNode<Panel>(
			"RoomManagementPanel/ScrollContainer/VBoxContainer/RoomListPanel"
		);

		// ---------------------------------------------------------
		// CONFIRMATION DIALOGS
		// ---------------------------------------------------------

		deleteRoomConfirmation = GetNode<ConfirmationDialog>(
			"DeleteRoomConfirmation"
		);

		closeRoomConfirmation = GetNode<ConfirmationDialog>(
			"CloseRoomConiframation"
		);

		// ---------------------------------------------------------
		// ROOM TEMPLATE
		// ---------------------------------------------------------

		roomTemplate = roomListContainer.GetChildren();

		SetRoomTemplateVisible(false);

		ConfigureScrollContainer();

		// ---------------------------------------------------------
		// BUTTON EVENTS
		// ---------------------------------------------------------

		backButton.Pressed += OnBackPressed;
		createRoomButton.Pressed += OnCreateRoomPressed;
		generateCodeButton.Pressed += OnGenerateCodePressed;
		saveButton.Pressed += OnSaveRoomPressed;
		cancelButton.Pressed += OnCancelCreateRoomPressed;

		deleteRoomConfirmation.Confirmed += OnDeleteRoomConfirmed;
		closeRoomConfirmation.Confirmed += OnCloseRoomConfirmed;

		// ---------------------------------------------------------
		// INITIAL STATE
		// ---------------------------------------------------------

		ResetCreateRoomForm();

		// Load rooms asynchronously.
		_ = RefreshRoomsAsync();
	}

	// ============================================================
	// SCROLL CONTAINER CONFIGURATION
	// ============================================================

	private void ConfigureScrollContainer()
	{
		if (roomScrollContainer == null)
			return;

		if (roomListContainer == null)
			return;

		// The VBox must be allowed to become taller than the
		// visible ScrollContainer.
		roomListContainer.SizeFlagsHorizontal =
			Control.SizeFlags.ExpandFill;

		roomListContainer.SizeFlagsVertical =
			Control.SizeFlags.ShrinkBegin;

		// Do NOT force a fixed height.
		roomListContainer.CustomMinimumSize = Vector2.Zero;

		// The ScrollContainer itself handles scrolling.
		roomScrollContainer.VerticalScrollMode =
			ScrollContainer.ScrollMode.Auto;

		roomScrollContainer.HorizontalScrollMode =
			ScrollContainer.ScrollMode.Disabled;

		// Make sure the content expands horizontally.
		roomScrollContainer.SizeFlagsHorizontal =
			Control.SizeFlags.ExpandFill;

		roomScrollContainer.SizeFlagsVertical =
			Control.SizeFlags.ExpandFill;
	}

	// ============================================================
	// BACK
	// ============================================================

	private void OnBackPressed()
	{
		GetTree().ChangeSceneToFile(
			"res://scene/Dashboard/UserDashboard/Professor Dashboard/ProfessorDashboard.tscn"
		);
	}

	// ============================================================
	// CREATE ROOM
	// ============================================================

	private void OnCreateRoomPressed()
	{
		ResetCreateRoomForm();

		createRoomWindow.PopupCentered();
	}

	// ============================================================
	// GENERATE ROOM CODE
	// ============================================================

	private async void OnGenerateCodePressed()
	{
		SetCreateControlsEnabled(false);

		try
		{
			generatedRoomCode =
				await RoomApiClient.GenerateRoomCodeAsync();

			codeLabel.Text = generatedRoomCode;

			roomCodeLabel.Visible = true;
			codeLabel.Visible = true;
		}
		catch (Exception ex)
		{
			GD.PrintErr(
				$"Generate room code failed: {ex.Message}"
			);

			codeLabel.Text = "Failed to generate code";

			roomCodeLabel.Visible = true;
			codeLabel.Visible = true;
		}
		finally
		{
			SetCreateControlsEnabled(true);
		}
	}

	// ============================================================
	// SAVE / CREATE ROOM
	// ============================================================

	private async void OnSaveRoomPressed()
	{
		string roomName = subjectNameInput.Text.Trim();

		if (string.IsNullOrWhiteSpace(roomName))
		{
			codeLabel.Text = "Subject name is required";

			roomCodeLabel.Visible = true;
			codeLabel.Visible = true;

			return;
		}

		if (string.IsNullOrWhiteSpace(generatedRoomCode))
		{
			codeLabel.Text = "Generate room code first";

			roomCodeLabel.Visible = true;
			codeLabel.Visible = true;

			return;
		}

		SetCreateControlsEnabled(false);

		try
		{
			await RoomApiClient.CreateRoomAsync(
				roomName,
				generatedRoomCode
			);

			createRoomWindow.Hide();

			ResetCreateRoomForm();

			await RefreshRoomsAsync();
		}
		catch (Exception ex)
		{
			GD.PrintErr(
				$"Create room failed: {ex.Message}"
			);

			codeLabel.Text = ex.Message;

			roomCodeLabel.Visible = true;
			codeLabel.Visible = true;
		}
		finally
		{
			SetCreateControlsEnabled(true);
		}
	}

	// ============================================================
	// CANCEL CREATE ROOM
	// ============================================================

	private void OnCancelCreateRoomPressed()
	{
		createRoomWindow.Hide();

		ResetCreateRoomForm();
	}

	// ============================================================
	// LOAD ROOMS
	// ============================================================

	private async Task RefreshRoomsAsync()
	{
		try
		{
			List<RoomSummaryDto> rooms =
				await RoomApiClient.GetRoomsAsync();

			RenderRooms(rooms);
		}
		catch (Exception ex)
		{
			GD.PrintErr(
				$"Load rooms failed: {ex.Message}"
			);

			RenderMessage("Unable to load rooms.");
		}
	}

	// ============================================================
	// RENDER ROOMS
	// ============================================================

	private void RenderRooms(List<RoomSummaryDto> rooms)
	{
		ClearRoomList();

		SetRoomTemplateVisible(false);

		// IMPORTANT:
		// Do NOT manually calculate the height.
		//
		// VBoxContainer automatically calculates its required
		// height based on all children.
		roomListContainer.CustomMinimumSize = Vector2.Zero;
		roomListPanel.CustomMinimumSize = Vector2.Zero;

		if (rooms == null || rooms.Count == 0)
		{
			RenderMessage("No rooms created yet.");
			return;
		}

		foreach (RoomSummaryDto room in rooms)
		{
			Control row = CreateRoomRow(room);

			row.SizeFlagsHorizontal =
				Control.SizeFlags.ExpandFill;

			row.SizeFlagsVertical =
				Control.SizeFlags.ShrinkBegin;

			roomListContainer.AddChild(row);
		}

		// ---------------------------------------------------------
		// FORCE CONTAINER RECALCULATION
		// ---------------------------------------------------------

		CallDeferred(
			Callable.From(RefreshRoomLayout)
		);
	}

	// ============================================================
	// REFRESH ROOM LAYOUT
	// ============================================================

	private void RefreshRoomLayout()
	{
		if (!IsInstanceValid(roomListContainer))
			return;

		// Ask Godot to recalculate container children.
		roomListContainer.QueueSort();

		roomListContainer.MinimumSizeChanged();

		roomListPanel.QueueRedraw();

		roomScrollContainer.QueueRedraw();
	}

	// ============================================================
	// CREATE ROOM ROW
	// ============================================================

	private Control CreateRoomRow(RoomSummaryDto room)
	{
		var row = new VBoxContainer
		{
			SizeFlagsHorizontal =
				Control.SizeFlags.ExpandFill,

			SizeFlagsVertical =
				Control.SizeFlags.ShrinkBegin
		};

		// Keep spacing reasonable.
		row.AddThemeConstantOverride(
			"separation",
			15
		);

		// ---------------------------------------------------------
		// SUBJECT
		// ---------------------------------------------------------

		var subjectLabel =
			(Label)roomTemplate[0].Duplicate();

		subjectLabel.Text =
			room.RoomName;

		subjectLabel.Visible = true;

		subjectLabel.SizeFlagsHorizontal =
			Control.SizeFlags.ExpandFill;

		row.AddChild(subjectLabel);

		// ---------------------------------------------------------
		// ROOM CODE
		// ---------------------------------------------------------

		var roomCodeLabel =
			(Label)roomTemplate[1].Duplicate();

		roomCodeLabel.Text =
			$"Code: {room.RoomCode}";

		roomCodeLabel.Visible = true;

		roomCodeLabel.SizeFlagsHorizontal =
			Control.SizeFlags.ExpandFill;

		row.AddChild(roomCodeLabel);

		// ---------------------------------------------------------
		// STUDENT COUNT
		// ---------------------------------------------------------

		var studentCountLabel =
			(Label)roomTemplate[2].Duplicate();

		studentCountLabel.Text =
			$"Students: {room.StudentCount}";

		studentCountLabel.Visible = true;

		studentCountLabel.SizeFlagsHorizontal =
			Control.SizeFlags.ExpandFill;

		row.AddChild(studentCountLabel);

		// ---------------------------------------------------------
		// STATUS
		// ---------------------------------------------------------

		var statusLabel =
			(Label)roomTemplate[3].Duplicate();

		statusLabel.Text =
			$"Status: {GetDisplayStatus(room.Status)}";

		statusLabel.Visible = true;

		statusLabel.SizeFlagsHorizontal =
			Control.SizeFlags.ExpandFill;

		row.AddChild(statusLabel);

		// ---------------------------------------------------------
		// ACTION BUTTONS
		// ---------------------------------------------------------

		var actionButtons =
			(HBoxContainer)roomTemplate[4].Duplicate();

		actionButtons.Visible = true;

		actionButtons.SizeFlagsHorizontal =
			Control.SizeFlags.ExpandFill;

		row.AddChild(actionButtons);

		// ---------------------------------------------------------
		// MANAGE
		// ---------------------------------------------------------

		var manageButton =
			actionButtons.GetNode<Button>("Manage");

		manageButton.Pressed +=
			() => OnManageRoomPressed(room);

		// ---------------------------------------------------------
		// CLOSE
		// ---------------------------------------------------------

		var closeButton =
			actionButtons.GetNode<Button>("Close");

		closeButton.Disabled =
			IsClosed(room.Status);

		closeButton.Pressed +=
			() => OnCloseRoomPressed(room.RoomId);

		// ---------------------------------------------------------
		// DELETE
		// ---------------------------------------------------------

		var deleteButton =
			actionButtons.GetNode<Button>("Delete");

		deleteButton.Pressed +=
			() => OnDeleteRoomPressed(room.RoomId);

		return row;
	}

	// ============================================================
	// MANAGE ROOM
	// ============================================================

	private void OnManageRoomPressed(RoomSummaryDto room)
	{
		MultiplayerRoomState.SetRoom(
			room.RoomId,
			room.RoomCode,
			room.RoomName
		);

		GetTree().ChangeSceneToFile(
			"res://scene/Dashboard/Modules/Room/ProfessorWaitingRoom.tscn"
		);
	}

	// ============================================================
	// DELETE ROOM
	// ============================================================

	private void OnDeleteRoomPressed(int roomId)
	{
		pendingDeleteRoomId = roomId;

		deleteRoomConfirmation.PopupCentered();
	}

	// ============================================================
	// CLOSE ROOM
	// ============================================================

	private void OnCloseRoomPressed(int roomId)
	{
		pendingCloseRoomId = roomId;

		closeRoomConfirmation.PopupCentered();
	}

	// ============================================================
	// CONFIRM CLOSE
	// ============================================================

	private async void OnCloseRoomConfirmed()
	{
		if (pendingCloseRoomId <= 0)
			return;

		try
		{
			await RoomApiClient.CloseRoomAsync(
				pendingCloseRoomId
			);

			pendingCloseRoomId = 0;

			await RefreshRoomsAsync();
		}
		catch (Exception ex)
		{
			GD.PrintErr(
				$"Close room failed: {ex.Message}"
			);
		}
	}

	// ============================================================
	// CONFIRM DELETE
	// ============================================================

	private async void OnDeleteRoomConfirmed()
	{
		if (pendingDeleteRoomId <= 0)
			return;

		try
		{
			await RoomApiClient.DeleteRoomAsync(
				pendingDeleteRoomId
			);

			pendingDeleteRoomId = 0;

			await RefreshRoomsAsync();
		}
		catch (Exception ex)
		{
			GD.PrintErr(
				$"Delete room failed: {ex.Message}"
			);
		}
	}

	// ============================================================
	// RESET CREATE ROOM FORM
	// ============================================================

	private void ResetCreateRoomForm()
	{
		generatedRoomCode = "";

		subjectNameInput.Text = "";

		codeLabel.Text = "";

		roomCodeLabel.Visible = false;
		codeLabel.Visible = false;

		SetCreateControlsEnabled(true);
	}

	// ============================================================
	// ENABLE / DISABLE CREATE CONTROLS
	// ============================================================

	private void SetCreateControlsEnabled(bool enabled)
	{
		subjectNameInput.Editable = enabled;

		generateCodeButton.Disabled =
			!enabled;

		saveButton.Disabled =
			!enabled;

		cancelButton.Disabled =
			!enabled;
	}

	// ============================================================
	// EMPTY / ERROR MESSAGE
	// ============================================================

	private void RenderMessage(string message)
	{
		ClearRoomList();

		var messageLabel = new Label
		{
			Text = message,

			SizeFlagsHorizontal =
				Control.SizeFlags.ExpandFill,

			SizeFlagsVertical =
				Control.SizeFlags.ShrinkBegin
		};

		roomListContainer.AddChild(messageLabel);

		CallDeferred(
			Callable.From(RefreshRoomLayout)
		);
	}

	// ============================================================
	// CLEAR GENERATED ROOMS
	// ============================================================

	private void ClearRoomList()
	{
		foreach (Node child in roomListContainer.GetChildren())
		{
			// Keep original template nodes.
			if (roomTemplate.Contains(child))
				continue;

			child.QueueFree();
		}
	}

	// ============================================================
	// SHOW / HIDE TEMPLATE
	// ============================================================

	private void SetRoomTemplateVisible(bool visible)
	{
		foreach (Node templateNode in roomTemplate)
		{
			if (templateNode is CanvasItem canvasItem)
			{
				canvasItem.Visible = visible;
			}
		}
	}

	// ============================================================
	// ROOM STATUS
	// ============================================================

	private static bool IsClosed(string status)
	{
		return string.Equals(
			status,
			"closed",
			StringComparison.OrdinalIgnoreCase
		);
	}

	private static string GetDisplayStatus(string status)
	{
		return IsClosed(status)
			? "Close"
			: "Ongoing";
	}
}
